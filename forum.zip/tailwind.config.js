/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./*.{php,html}",
  ],
  theme: {},
  plugins: [],
}
