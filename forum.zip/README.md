Simple forum in PHP
---
Nothing fancy, just a simple forum in plain PHP

Reister, login, logout are working and only users who are logged in can write anything.

The database login details are not publised, you need to write into the ```database.php```
Variables:
* ```$username```
* ```$password```

